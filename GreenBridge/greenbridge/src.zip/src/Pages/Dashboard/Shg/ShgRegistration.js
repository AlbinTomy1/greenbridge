import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
// import './ShgRegistration.css'; // Import the CSS

const ShgRegistration = () => {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    contact_person: '',
    contact_email: '',
    contact_phone: '',
  });
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post('/api/shg/shgs/', formData)
      .then(response => {
        alert('Registration submitted. Awaiting approval.');
        navigate('/shg-dashboard');
      })
      .catch(error => {
        console.error(error);
        alert('Failed to register. Try again later.');
      });
  };

  return (
    <div className="shg-registration-container">
      <h2 className="form-title">SHG Registration</h2>
      <form onSubmit={handleSubmit} className="shg-registration-form">
        <div className="form-group">
          <label htmlFor="name">SHG Name</label>
          <input 
            type="text" 
            id="name" 
            name="name" 
            placeholder="Enter SHG Name" 
            value={formData.name} 
            onChange={handleChange} 
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="description">Description</label>
          <textarea 
            id="description" 
            name="description" 
            placeholder="Enter Description" 
            value={formData.description} 
            onChange={handleChange} 
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="contact_person">Contact Person</label>
          <input 
            type="text" 
            id="contact_person" 
            name="contact_person" 
            placeholder="Enter Contact Person" 
            value={formData.contact_person} 
            onChange={handleChange} 
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="contact_email">Contact Email</label>
          <input 
            type="email" 
            id="contact_email" 
            name="contact_email" 
            placeholder="Enter Contact Email" 
            value={formData.contact_email} 
            onChange={handleChange} 
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="contact_phone">Contact Phone</label>
          <input 
            type="tel" 
            id="contact_phone" 
            name="contact_phone" 
            placeholder="Enter Contact Phone" 
            value={formData.contact_phone} 
            onChange={handleChange} 
            required
          />
        </div>
        <button type="submit" className="submit-button">Submit</button>
      </form>
    </div>
  );
};

export default ShgRegistration;
