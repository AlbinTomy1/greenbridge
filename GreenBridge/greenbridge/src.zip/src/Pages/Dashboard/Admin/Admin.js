import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Admin = () => {
  const [shgs, setShgs] = useState([]);

  useEffect(() => {
    axios.get('/api/adminpanel/admin/shgs/')
      .then(response => {
        setShgs(response.data);
      })
      .catch(error => {
        console.error('Error fetching SHGs', error);
      });
  }, []);

  const approveSHG = (id) => {
    axios.post(`/api/adminpanel/admin/shgs/${id}/approve/`)
      .then(() => {
        alert('SHG Approved');
        setShgs(shgs.filter(shg => shg.id !== id));
      })
      .catch(error => console.error('Error approving SHG', error));
  };

  const rejectSHG = (id) => {
    axios.post(`/api/adminpanel/admin/shgs/${id}/reject/`)
      .then(() => {
        alert('SHG Rejected');
        setShgs(shgs.filter(shg => shg.id !== id));
      })
      .catch(error => console.error('Error rejecting SHG', error));
  };

  return (
    <div>
      <h2>Pending SHG Registrations</h2>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Contact Person</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {shgs.map((shg) => (
            <tr key={shg.id}>
              <td>{shg.id}</td>
              <td>{shg.name}</td>
              <td>{shg.contact_person}</td>
              <td>
                <button onClick={() => approveSHG(shg.id)}>Approve</button>
                <button onClick={() => rejectSHG(shg.id)}>Reject</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Admin;
