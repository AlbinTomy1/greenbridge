import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { CgProfile } from "react-icons/cg";
import { GoHeart } from "react-icons/go";
import { IoBagHandleOutline } from "react-icons/io5";
import { AiOutlineSearch } from "react-icons/ai";
import logo1 from './assets/logo.png';
import 'bootstrap/dist/css/bootstrap.min.css';
import './Header.css';


const Dropdown = ({ isOpen, toggleDropdown }) => (
    <div className="dropdown-container">
        <div className="dropbtn" onClick={toggleDropdown}>
            <CgProfile size={20} />
            <span className="icon-label">PROFILE</span>
        </div>
        {isOpen && (
            <div className="dropdown-content">
                <Link to="/login">Login</Link>
                <Link to="/signup">Signup</Link>
            </div>
        )}
    </div>
);

const LandingPage = () => {
    const [isDropdownOpen, setIsDropdownOpen] = useState(false);

    const toggleDropdown = () => {
        setIsDropdownOpen(!isDropdownOpen);
    };

    return (
        <header className="header-container navbar navbar-expand-lg navbar-light">
            <div className="container d-flex align-items-center justify-content-between">
                {/* Left Side: Logo */}
                <div className="navbar-brand">
                    <Link to="/" className="logo-link">
                        <img src={logo1} alt="Company Logo" className="logo" />
                    </Link>
                </div>

                {/* Center: Navigation Links */}
                <nav className="navbar-nav mx-auto">
                    <ul className="nav d-flex align-items-center">
                        <li className="nav-item">
                            <Link to="/men" className="nav-link">FURNITURE</Link>
                        </li>
                        <li className="nav-item">
                            <Link to="/women" className="nav-link">LIGHTING</Link>
                        </li>
                        <li className="nav-item">
                            <Link to="/kids" className="nav-link">DECORATION</Link>
                        </li>
                        <li className="nav-item">
                            <Link to="/home-living" className="nav-link">BEDS & MATRESSES</Link>
                        </li>
                    </ul>
                </nav>

                {/* Right Side: Search Bar and Icons */}
                <div className="d-flex align-items-center">
                    <form className="search-bar">
                        <AiOutlineSearch size={20} className="search-icon" />
                        <input
                            type="text"
                            className="search-input"
                            placeholder="Search for products, brands and more"
                        />
                    </form>
                    <ul className="navbar-nav ml-auto d-flex align-items-center">
                        <li className="nav-item text-center">
                            <Dropdown isOpen={isDropdownOpen} toggleDropdown={toggleDropdown} />
                        </li>
                        <li className="nav-item text-center">
                            <Link to="/wishlist" className="nav-link">
                                <GoHeart size={20} />
                                <span className="icon-label">Wishlist</span>
                            </Link>
                        </li>
                        <li className="nav-item text-center">
                            <Link to="/cart" className="nav-link">
                                <IoBagHandleOutline size={20} />
                                <span className="icon-label">Bag</span>
                            </Link>
                        </li>
                    </ul>
                </div>
            </div>
        </header>
    );
};

export default LandingPage;