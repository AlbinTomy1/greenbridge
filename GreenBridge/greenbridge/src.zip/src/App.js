import React from 'react';
import './App.css';
import { BrowserRouter as Router,Routes,Route } from 'react-router-dom';
// import RegLogin from './Authentication/RegLogin';
import './Login.css';
// import LandingPage from './LandingPage';
import Admin from './Pages/Dashboard/Admin/Admin';
import ShgRegistration from './Pages/Dashboard/Shg/ShgRegistration';
import './Pages/Dashboard/Shg/ShgRegitration.css';


function App() {
  return (
    <Router>
      <Routes>
        < Route path="/shg" element={<ShgRegistration/>} />
        <Route path="/admin" element={<Admin />} />
        {/* <Route path="/login" element={<RegLogin />} />
        <Route path="/signup" element={<RegLogin />} /> */}
      </Routes>
    </Router>
  );
}

export default App;
